//
//  OnlineStore_2_0App.swift
//  OnlineStore.2.0
//
//  Created by Dario Marquez on 14/9/25.
//

import SwiftUI

@main
struct OnlineStoreApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}
